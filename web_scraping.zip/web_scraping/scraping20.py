import pandas as pd
from bs4 import BeautifulSoup
import requests
import sqlite3

#Define our required attributes
url = 'https://web.archive.org/web/20230902185655/https://en.everybodywiki.com/100_Most_Highly-Ranked_Films'
table_name = 'Top20_Films'
db_name1 = 'Movies20.db'
csv_path1 = 'D:\\python_project\\web_scraping\\Top20_Films.csv'
df_attr = pd.DataFrame(columns=['Film', 'Year', 'Rotten Tomatoes'' Top 100'])
count = 0
data_list = []

#Loading the Page for Scraping
page = requests.get(url).text
data = BeautifulSoup(page, 'html.parser')

#Extract the Table from HTML Page
tables = data.find_all('tbody')
rows = tables[0].find_all('tr')

#Extract Content of Selected Table
for row in rows:
    if count < 20:
        col = row.find_all('td')
        if len(col) != 0:
            data_list.append({
                "Film": col[1].contents[0],
                "Rotten Tomatoes' Top 100": col[3].contents[0]
            })
            year = int(col[2].contents[0])
            if year >= 2000:
                data_list.append(
                    {
                        "Year": year
                    }
                )
            count += 1
    else:
        break
#Convert LIst into DataFrame
df = pd.DataFrame(data_list)

#Show our Results
print(df)

# #Save the result in csv file
df.to_csv(csv_path1)

#Store the Data in Datbase
conn = sqlite3.Connection(db_name1)
df.to_sql(table_name, conn, if_exists= 'replace', index= False)
conn.close                    