import datetime 
import pandas as pd
import requests
from bs4 import BeautifulSoup
import sqlite3

#      Define All Parameters      #
log_file = 'code_log.txt'
url = 'https://web.archive.org/web/20230908091635/https://en.wikipedia.org/wiki/List_of_largest_banks'
data_list = []
csv_file = 'D:\\python_project\\final\\exchange_rate.csv'
path = 'D:\\python_project\\final\\out_put.csv'
db_name = 'Banks.db'
table_name = 'Largest_banks'
conn = sqlite3.Connection(db_name)



#Log Function
def log_progress(message):
    time_form = '%Y-%M-%D-%H:%M:%S'
    now = datetime.datetime.now()
    now_form = now.strftime(time_form)

    with open (log_file, 'a') as f:
        f.write(now_form + ',' + message + '\n')  

#Extract Function
def extract(url, table_attribs):
    page = requests.get(url).text
    data = BeautifulSoup(page, 'html.parser')

    tables = data.find_all('tbody')
    rows = tables[0].find_all('tr') 

    df = pd.DataFrame(columns = table_attribs)

    for row in rows:
        col = row.find_all('td')
        if len(col) != 0:
            data_list.append(
                {
                    'Name' : col[1].find_all('a')[1]['title'],
                    'MC_USD_Billion' : float(col[2].contents[0][:-1])
                }
            )
    df = pd.DataFrame(data_list)
    return df
table_att = ['Name', 'MC_USD_Billion']
df = extract(url, table_att)

#Transformation
def transform(df , csv_file):
    exchange = pd.read_csv(csv_file)
    exchange = exchange.set_index("Currency").to_dict()["Rate"]

    df['MC_GBP_Billion'] = (df['MC_USD_Billion'] * exchange['GBP']).round(2)
    df['MC_EUR_Billion'] = (df['MC_USD_Billion'] * exchange['EUR']).round(2)
    df['MC_INR_Billion'] = (df['MC_USD_Billion'] * exchange['INR']).round(2)

    return df

out = transform(df , csv_file)
#print(out)

#Load to csv
def load_to_csv(df , path):
    df.to_csv(path)

#Load to Database
def load_to_db(df, sql_connection, table_name):
    df.to_sql(table_name, sql_connection, if_exists = 'replace', index = False)

#Run Queries
def run_queries(query_statment, sql_connection):
    print(query_statment)
    query_output = pd.read_sql(query_statment, sql_connection)
    print(query_output)

#      Our Outputs      #
log_progress("ETL Started....")

#EXTRACTION
log_progress("Extraction Started")
extraction = extract(url, table_att)
#print("EXTRACTION")
#print(extraction)
log_progress("Extraction Ended")

#TRANSFORMATION
log_progress("Transformation Started")
transformation = transform(extraction, csv_file)
#print("TRANSFORMATION")
#print(transformation)
log_progress("Transformation Ended")

#LOADING TO CSV
log_progress("Loading Started")
load_to_csv(transformation, path)
log_progress("Loading Ended")

#LOADING TO DB
log_progress("DB_creation Started")
load_to_db(transformation, conn, table_name)
log_progress("DB_creation Started")

#RUN SOME QUERIES
log_progress("Queries Started")
query1 = f'SELECT * FROM {table_name}'
output1 = pd.read_sql(query1, conn)
print("Query1")
#print(output1)
run_queries(query1, conn)

query2 = f'SELECT AVG(MC_GBP_Billion) FROM {table_name}'
output2 = pd.read_sql(query2, conn)
print("Query2")
#print(output2)
run_queries(query2, conn)

query3 = f'SELECT Name from {table_name} Limit 5'
output3 = pd.read_sql(query3, conn)
print("Query3")
#print(output3)
run_queries(query3, conn)

log_progress("Queries Started")

log_progress("ETL Ended")

conn.close()