import sqlite3
import pandas as pd

#Database Intiation
conn = sqlite3.connect('STAFF.db')

#table 1
table_name = 'INSTRUCTOR'
att_list = ['ID', 'FName', 'LName', 'City', 'Code']

#Define the file path
file_path = 'D:\\python_project\\database_creation\\INSTRUCTION.CSV'
df = pd.read_csv(file_path, names= att_list)

#Create the Database
df.to_sql(table_name, conn, if_exists= 'replace', index= False)
print("Created successfully")

#          Retreive Data           #
#1
# statment = f'select FName from {table_name}'
# excute = pd.read_sql(statment, conn)
# print(excute)

# #2
# stat2 = f'select * from {table_name}'
# output = pd.read_sql(stat2, conn)
# print(output)

#          Append Data           #
data = {'ID': [200],
        'FName': ['Mariam'],
        'LName': ['Taha'],
        'City': ['Egypt'],
        'Code': ['EG']}
data_append = pd.DataFrame(data)

data_append.to_sql(table_name, conn, if_exists= 'append', index= False)
print("Appended Successfully")

#show appended data
stat2 = f'select * from {table_name}'
output = pd.read_sql(stat2, conn)
print(output)

conn.close()