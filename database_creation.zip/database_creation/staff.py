import sqlite3
import pandas as pd

database = sqlite3.connect('STAFF.db')
table_name = "STAFF"
att_list = ['DEPT_ID', 'DEP_NAME', 'MANAGER_ID', 'LOC_ID']

# Append Values

data = {'DEPT_ID': [9],
        'DEP_NAME': ['Quality Assurance'],
        'MANAGER_ID': [30010],
        'LOC_ID': ['L0010']}

df = pd.DataFrame(data)

#df.to_sql(table_name, database, if_exists= 'append', index= False)
print("Values Appended Successfully")

#Queries
select = f'select * from {table_name}'
output = pd.read_sql(select, database)
#print(output)

select2 = f'select DEP_NAME from {table_name}'
output2 = pd.read_sql(select2, database)
#print(output2)

count = f'select count(*) from {table_name}'
output3 = pd.read_sql(count, database)
print(output3)