import pandas as pd
import datetime
import glob
import xml.etree.ElementTree as ET

log_file = "log_file.txt"
target_file = "transformeted_data.csv"

######        Extract           ######
#extract from csv file
def extract_from_csv(file_to_process):
    dataframe = pd.read_csv(file_to_process)
    return dataframe

#extract from json file
def extract_from_json(file_to_process):
    dataframe = pd.read_json(file_to_process, lines= True)
    return dataframe

#etract from xml file
def extract_from_xml(file_to_process):
    dataframe = pd.DataFrame(columns= ["name", "height", "weight"])
    tree = ET.parse(file_to_process)
    root = tree.getroot()

    for person in root:
        name = person.find("name").text 
        height = float(person.find("height").text) 
        weight = float(person.find("weight").text)
        dataframe = pd.concat([dataframe, pd.DataFrame([{"name": name, "height": height, "weight": weight}])], ignore_index= True)

    return dataframe

#function to call files for extraction
def extract():
    extracted_data = pd.DataFrame(columns=["name", "height", "weight"])

    #loop in csv files
    for csvfile in glob.glob("*csv"):
        extracted_data = pd.concat([extracted_data, pd.DataFrame(extract_from_csv(csvfile))], ignore_index= True)

    #loop in json files
    for jsonfile in glob.glob("*json"):
        extracted_data = pd.concat([extracted_data, pd.DataFrame(extract_from_json(jsonfile))], ignore_index= True)

    #loop in xml file
    for xmlfile in glob.glob("*xml"):
        extracted_data = pd.concat([extracted_data, pd.DataFrame(extract_from_xml(xmlfile))], ignore_index= True)

    return extracted_data

######        Transform           ######
def transform(data):
    #transform inches into meters
    data['height'] = round(data.height * 0.0254, 2)

    #transform pounds into kilograms
    data['weight'] = round(data.weight * 0.45359237, 2)

    return data

######        Load Data To CSV           ######
def load_data(transformed_data, target_file):
    transformed_data.to_csv(target_file)


######        Log Time           ######
def log_progress(message):
    timestamp_format = '%Y-%M-%D-%H-%M-%S'
    now = datetime.datetime.now()
    timestamp = now.strftime(timestamp_format)

    #write time of start end end for each process
    with open(log_file, 'a') as f:
        f.write(timestamp + ',' + message + '\n')


######        The Final Result           ######
log_progress("ETL Started")

#Extraction
log_progress("Extract Start")
extracted_data = extract()
log_progress("Extract End")

#Transformation
log_progress("Transform Start")
transformed_data = transform(extracted_data)
log_progress("Transform End")

#Loading
log_progress("Load Start")
load_data(transformed_data, target_file)
log_progress("Load End")

log_progress("ETL Ended")